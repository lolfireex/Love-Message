"use client"

import { useState } from "react"

export default function LoveMessage() {
  const [message] = useState("I Love You ❤️")

  function showLove() {
    alert("You are the most special person in my life! 💞")
  }

  return (
    <div className="text-center">
      <h1 className="text-5xl text-white font-pacifico animate-fadeIn drop-shadow-lg">{message}</h1>
      <button
        className="mt-5 px-6 py-3 text-2xl rounded-full bg-[#ff4f7b] text-white cursor-pointer 
                  transition-all duration-300 shadow-lg hover:bg-[#ff2e63] hover:scale-110"
        onClick={showLove}
      >
        Click Me 💖
      </button>
    </div>
  )
}

