"use client"
import LoveMessage from "@/components/love-message"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-r from-[#ff758c] to-[#ff7eb3]">
      <LoveMessage />
    </main>
  )
}

